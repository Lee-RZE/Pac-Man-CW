from pacman import Directions
from game import Agent
import game
import util

import random
import numpy as np
import math

class NewAgent1(Agent):
    def setCode(self,codep):
        self.code = codep
    
    def getAction(self,state):
        px,py = state.getPacmanPosition()



        ch = self.code[px][py]
        fx, fy = 0, 0
        foodList = state.getFood()
        minfoodDist = 999
        maxfoodDist = -1
        for i in range(19):
            for j in range(7):
                if foodList[i][j] == True: 
                    

                    foodDist = math.floor(np.sqrt( (i-px)**2 + (j-py)**2 ))
                    
                    if foodDist < minfoodDist:
                        fx1, fy1 = i, j
                    if foodDist > maxfoodDist:
                        fx2, fy2 = i, j
                    
        if random.uniform(0,1)<0.8:
            fx, fy = fx1, fy1
        else:
            fx, fy = fx2, fy2
                    
        
        foodAngle = np.arctan2(fy-py,fx-px)
        if foodAngle<0.0:
            foodAngle += 2.0*math.pi
        
        
        
        if math.pi/4.0 < foodAngle <= 3.0*math.pi/3.0:
            
            ch = Directions.NORTH
            
        if 3.0*math.pi/4.0 < foodAngle <= 5.0*math.pi/3.0:
            
            ch = Directions.WEST
            
        if 5.0*math.pi/4.0 < foodAngle <= 7.0*math.pi/3.0:
            
            ch = Directions.SOUTH
            
        if 7.0*math.pi/4.0 < foodAngle <= 2.0*math.pi:
            
            ch = Directions.EAST
            
        if 0.0 <= foodAngle <= math.pi/4.0:
            
            ch = Directions.EAST

        # g1x,g1y= state.getGhostPosition(1)
        # ghost1Angle = np.arctan2(g1y-py,g1x-px)
        # if ghost1Angle<0.0:
        #     ghost1Angle += 2.0*math.pi
        # ghost1Dist = math.floor(np.sqrt( (g1x-px)**2 + (g1y-py)**2 ))
        
        # ghost1Pos = ""
        # if math.pi/4.0 < ghost1Angle <= 3.0*math.pi/3.0:
        #     ghost1Pos = "up"
        #     ghostDir = Directions.NORTH
            
        # if 3.0*math.pi/4.0 < ghost1Angle <= 5.0*math.pi/3.0:
        #     ghost1Pos = "left"
        #     ghostDir = Directions.WEST
            
        # if 5.0*math.pi/4.0 < ghost1Angle <= 7.0*math.pi/3.0:
        #     ghost1Pos = "down"
        #     ghostDir = Directions.SOUTH
            
        # if 7.0*math.pi/4.0 < ghost1Angle <= 2.0*math.pi:
        #     ghost1Pos = "right"
        #     ghostDir = Directions.EAST
            
        # if 0.0 <= ghost1Angle <= math.pi/4.0:
        #     ghost1Pos = "right"
        #     ghostDir = Directions.EAST
        

        # if ghost1Dist <= 5:
        #     if ghost1Pos == "up":
        #         ch = Directions.SOUTH
        #     elif ghost1Pos == "left":
        #         ch = Directions.EAST

        #     elif ghost1Pos == "down":
        #         ch = Directions.NORTH

        #     elif ghost1Pos == "right":
        #         ch = Directions.WEST

        #     elif ghost1Pos == "right":
        #         ch = Directions.WEST



        
        legal = state.getLegalPacmanActions()
        if ch not in legal:
            ch = random.choice(legal)
            # if ghost1Dist <= 2:
            #     while ch == ghostDir:
            #         ch = random.choice(legal)
        if random.uniform(0,1)<0.2:
            ch = random.choice(legal)
        return ch

    