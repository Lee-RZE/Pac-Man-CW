import matplotlib.pyplot as plt
from pacman import *
import ghostAgents
import layout
import textDisplay
import graphicsDisplay
import copy
import numpy as np
from pprint import pprint
from matplotlib.pylab import style
import sys


## set up the parameters to newGame
numtraining = 0
timeout = 30
beQuiet = True
layout=layout.getLayout("capsuleClassic")
pacmanType = loadAgent("NewAgent1", True)
numGhosts = 0
# ghosts = [ghostAgents.DirectionalGhost(i+1) for i in range(numGhosts)]
ghosts = [ghostAgents.RandomGhost(i+1) for i in range(numGhosts)]
catchExceptions=True

def run(code,noOfRuns):
    rules = ClassicGameRules(timeout)
    games = []
    if beQuiet:
        gameDisplay = textDisplay.NullGraphics()
        rules.quiet = True
    else:
        timeInterval = 0.001
        textDisplay.SLEEP_TIME = timeInterval
        gameDisplay = graphicsDisplay.PacmanGraphics(1.0, timeInterval)
        rules.quiet = False
    for gg in range(noOfRuns):
        thePacman = pacmanType()
        thePacman.setCode(code)
        game = rules.newGame( layout, thePacman, ghosts, gameDisplay, \
                          beQuiet, catchExceptions )
        game.run()
        games.append(game)
    scores = [game.state.getScore() for game in games]
    return sum(scores) / float(len(scores))

####### genetic algorithm

options = [Directions.NORTH, Directions.EAST, Directions.SOUTH, Directions.WEST]
    
def mutate(parentp,numberOfMutations=10):
    parent = copy.deepcopy(parentp)
    for _ in range(numberOfMutations):
        xx = random.randrange(19)
        yy = random.randrange(10)
        parent[xx][yy] = random.choice(options)
    return parent



def runGA(popSiz=10,timescale=500,numberOfRuns=2,tournamentSize=4):

    ## create random initial population
    population = []
    for _ in range(popSiz):
        program = np.empty((19,10),dtype=object)
        for xx in range(19):
            for yy in range(10):
                program[xx][yy] = random.choice(options)
        population.append(program)
            
    print("Beginning Evolution")
    averages = []
    bests = []
    for i in range(timescale):

        ## evaluate population
        print('No.'+str(i+1))

        fitness = []
        for pp in population:
            print(".",end="",flush=True)
            fitness.append(run(pp,numberOfRuns))
        print("\n******")
        print(fitness)
        averages.append(1000+sum(fitness)/popSiz)
        print("av ",1000+sum(fitness)/popSiz)
        bests.append(1000+max(fitness))
        print("max ",1000+max(fitness))

        popFitPairs = list(zip(population,fitness))
        newPopulation = []
        BestGene = max(popFitPairs,key=lambda x:x[1])[0]

        for _ in range(popSiz-1):
                # select a parent from a "tournament"
                tournament1 = random.sample(popFitPairs,tournamentSize)
                parent1 = max(tournament1,key=lambda x:x[1])[0]
                tournament2 = random.sample(popFitPairs,tournamentSize)
                parent2 = max(tournament2,key=lambda x:x[1])[0]
                while (parent1 == parent2).all():
                    tournament2 = random.sample(popFitPairs,tournamentSize)
                    parent2 = max(tournament2,key=lambda x:x[1])[0]
                child  = copy.deepcopy(parent1)
                for i in range(19):
                    for j in range(10):
                        if random.random() > 0.5:
                            child[i][j] = parent2[i][j]

                # mutate the parent
                child = mutate(child)
                newPopulation.append(child)
                ## ADD CODE TO CROSSOVER PARENTS
        ## ADD CODE TO KEEP BEST POPULATION MEMBER
        newPopulation.append(BestGene)
        population = copy.deepcopy(newPopulation)
    print(averages)
    print(bests)
    style.use('ggplot')
    plt.plot(averages,linewidth=1,  label='Average')
    plt.plot(bests, linewidth=1, label='Best')
    plt.legend(loc = 'best')
    plt.xlabel('Iterations')
    plt.ylabel('Score')

    plt.show()

    ## ADD CODE TO PLOT averages AND bests



def runTest():
    fitness = []
    runTimes = 10
    for i in range(runTimes):
        program = np.empty((19,10),dtype=object)
        for xx in range(19):
            for yy in range(10):
                program[xx][yy] = Directions.EAST
        print('No.' + str(i+1)+': ', end = '')
        
        fitness.append(run(program,2))
        print(fitness[i])
    print(fitness)
    
    print(sum(fitness)/runTimes)
    print(max(fitness))


runTest()    
# runGA()
        

